
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="images/icon/icon.ico">

    <title>KMITL Wallet - Shop</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template300*162 -->
    <link href="scss/all.css" rel="stylesheet">
      <link href="scss/vbox.css" rel="stylesheet">

  </head>

<body>
<div class="container-fluid">
      <div class="row">
        <div class="col">
          <div class="card">
            <div class="container" style="margin-left:0;margin-top:10;z-index:5">

  				<script>
  document.write('<a class="back" href="javascript:history.back()"> < BACK </a>');
</script>
            </div>
            <div class="form text-center">
              <img class="mb-4 logo" src="images/logo.png" alt="logo" >

              <div class="whitebg">
              <div class="container" >
                <div class="vbox" style="height: 100%; width: 100%;">
      <div>Hello 1</div>
      <div>Hello 1</div>
      <div>Hello 1</div>
      <div>Hello 3</div>
  </div>

              </div>
              </div>



              <p class="mt-5 mb-3 text-muted">&copy; 2018 CE-KMITL</p>
            </div>
          </div>
        </div>
      </div>
  </div>

</body>
</html>
