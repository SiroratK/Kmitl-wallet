
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="images/icon/icon.ico">

    <title>KMITL Wallet - Show Balance</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template300*162 -->
    <link href="scss/all.css" rel="stylesheet">

    <style>
    .inload {
      z-index:1000;
      position:absolute;
      margin:auto;
      left:0;
      right:0;
      margin-top:50px;


    }
    </style>
  </head>

<body>
<div class="container-fluid">
      <div class="row">
        <div class="col">
          <div class="card">
            <div class="container" style="margin-left:0;margin-top:10;z-index:5">

  				<script>
  document.write('<a class="back" href="javascript:history.back()"> < BACK </a>');
</script>
            </div>
            <div class="form text-center">
              <img class="mb-4 logo" src="images/logo.png" alt="logo" >

<div class="container" align="center" >
<center>
<p class="textRes inload">Balance<br> 0 ฿</p>
</center>

<div class="loader" >

              </div>




</div>
<div class="row" style="margin-top:50px;">
  <div class="col-md-4"></div>
  <div class="col-md-4">
  <a href="menu.php">  <button class="btn btn-lg btn-primary btn-block inner" >Main Menu</button></a>
  </div>
  <div class="col-md-4"></div>
</div>

<div class="row">
    <div class="col-md-2"></div>
    <div class="col-md-4" style="margin-top:10px;">
        <a href="changePass.php"><button style="align-item: center; margin:auto" class="btn btn-lg btn-primary btn-block textResWhite">Change Password</button></a>
    </div>
    <div class="col-md-4" style="margin-top:10px;">
        <a href="changepin.php"><button style="align-item: center; margin:auto" class="btn btn-lg btn-primary btn-block textResWhite" type="submit">Change PIN Code</button></a>
    </div>
    <div class="col-md-2"></div>
</div>

              <p class="mt-5 mb-3 text-muted">&copy; 2018 CE-KMITL</p>


          </div>
        </div>
      </div>
  </div>

</body>
</html>
